# Heart & Bloom — Shopify Store Assessment Deliverables

## 1. Theme Recommendation

**Recommended Theme: Dawn (Shopify 2.0 — Free)**

**Why Dawn:**
- Shopify's official 2.0 theme — built for performance and scalability
- Section/block architecture: easy to replicate page layouts for all 10 age kits
- Lightweight (~200KB JS), passes Core Web Vitals out of the box
- Mobile-first by default
- Metafield support for custom product data (age range, domain tags)
- No bloat — fast load times without heavy animations
- Active support + free updates from Shopify

**Alternative:** Craft (Free, Shopify 2.0) — also excellent for product-focused DTC stores.

---

## 2. Store Structure (Shopify)

```
heartandbloom.myshopify.com/
├── Homepage                    → Customised Dawn homepage template
├── /collections/all-kits       → Collection page (10 products)
├── /products/2-3-years-kit     → Product page template (reusable for all 10)
├── /pages/about                → About page
├── /pages/faq                  → FAQ page  
├── /pages/contact              → Contact page (+ Contact form)
├── /policies/refund-policy     → Placeholder
├── /policies/privacy-policy    → Placeholder
└── /policies/terms-of-service  → Placeholder
```

---

## 3. Apps Used

**Minimal app footprint — only 2 apps used:**

| App | Purpose | Cost |
|-----|---------|------|
| **Tidio** (or Shopify Inbox) | WhatsApp-style chat support widget | Free |
| **Judge.me** | Product reviews & star ratings (builds trust) | Free plan available |

**Not used (deliberately avoided):**
- Page builders (Shogun, Pagefly) — Dawn's native sections handle all layouts cleanly
- Heavy upsell apps — keep load time fast
- Popup apps — friction for a trust-first brand

---

## 4. Scalability Plan for All 10 Kits

Each of the 10 age kits uses the **same product page template** with different:
- Product title & description (via Shopify editor)
- Age range tag (0-1, 1-2, 2-3... etc.)
- Emoji/image per kit
- Collection filter tags

**Metafields to create (once):**
- `custom.age_range` → "2–3 Years"
- `custom.kit_emoji` → "🌱"
- `custom.skill_tags` → JSON array of skill names
- `custom.domain_count` → "8"

This means adding Kit #4 takes ~10 minutes — just duplicate the product and fill in metafields.

---

## 5. Mobile-First Implementation Notes

- All sections use CSS Grid with `auto-fit` / responsive breakpoints
- CTA buttons are minimum 44px tap target (WCAG AA)
- Sticky header collapses to logo + hamburger on mobile
- Product page: gallery stacks above info on mobile
- Age grid: 2 columns on mobile, 5 columns on desktop
- Collection grid: 1 column mobile → 2 tablet → 3 desktop

---

## 6. Speed Optimisation

- Images: Compressed to WebP via Shopify CDN (automatic)
- Fonts: Preloaded with `rel="preload"` — only 2 font families
- No jQuery — vanilla JS only
- No external CSS frameworks
- Lazy loading on all below-fold images
- Minimal JavaScript (~3KB total custom JS)
- Trust strips and announcement bar are CSS-only

---

## 7. Conversion Architecture

**Homepage:**
- Hero → immediate value prop + primary CTA
- Trust strip → social proof anchors
- Age grid → reduces decision fatigue (direct path to right product)
- How it works → removes uncertainty
- Why H&B → handles objections

**Product Page:**
- Price shown early (₹5,500 — clear and prominent)
- Short description above fold (no scrolling to understand value)
- Skill tags → quick scanning for busy parents
- Step-by-step how it works → removes effort perception
- Trust badges (Free Shipping / COD / Safe) below Add to Cart
- Product FAQs inline → removes last-mile hesitation

**Collection Page:**
- Filter chips for age grouping (0–3 / 3–6 / 6–10)
- Best Seller badge drives social proof
- Card design shows price + Add to Cart without clicking through

---

## 8. GitHub Repo Details

**Title:** `heartandbloom-shopify-store`

**Description:**
> Shopify 2.0 store prototype for Heart & Bloom — a developmental activity kit brand for children 0–10 years. Built on the Dawn theme with a mobile-first, high-conversion layout. Includes homepage, product page, collection page, about page, FAQ and contact page. Scalable structure for all 10 age kits using Shopify metafields and reusable section templates.

**Tags:**
`shopify` `shopify-2` `dawn-theme` `ecommerce` `mobile-first` `html` `css` `children` `edtech` `conversion-optimisation`
