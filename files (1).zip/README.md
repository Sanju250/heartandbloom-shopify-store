# Heart & Bloom — Shopify Store Prototype

A complete Shopify store prototype for **Heart & Bloom**, a developmental activity kit brand for children aged 0–10 years. Built as a Shopify Developer Intern skills assessment.

## Project Structure

```
heartandbloom-site/
├── index.html        # Full store prototype — all 6 pages, fully navigable
├── DELIVERABLES.md   # Theme choice, apps, scalability plan, GitHub details
└── README.md         # This file
```

## Pages Included

| Page | Description |
|------|-------------|
| **Homepage** | Hero, trust strip, age grid (10 kits), How It Works, What's Inside, Why H&B |
| **Product Page** | 2–3 Years kit — gallery, skills, Add to Cart, trust badges, inline FAQs |
| **Collection Page** | All 10 kits with filter chips and card grid |
| **About Page** | Mission, stats, team profiles |
| **FAQ Page** | Categorised accordion with sidebar navigation |
| **Contact Page** | Contact methods + form |

## Tech Stack

- Pure HTML / CSS / Vanilla JS (Shopify theme equivalent)
- Google Fonts: Playfair Display + Plus Jakarta Sans
- No frameworks, no dependencies
- Mobile-first responsive layout
- IntersectionObserver scroll reveal animations
- CSS custom properties for full theme consistency

## Shopify Implementation

- **Theme:** Dawn (Shopify 2.0, Free)
- **Apps:** Shopify Inbox + Judge.me (free tiers only)
- **Scalability:** One product template + Metafields for all 10 age kits
- **Deployment:** Upload to Shopify development store → Enable GitHub Pages for prototype preview

## Author

Shopify Developer Intern Assessment — 2025
